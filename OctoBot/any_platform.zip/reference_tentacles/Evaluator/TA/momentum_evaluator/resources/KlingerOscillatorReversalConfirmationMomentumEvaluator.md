Uses [Klinger Oscillator](https://www.investopedia.com/terms/k/klingeroscillator.asp) to find reversals.

Returns True on reversal confirmation.