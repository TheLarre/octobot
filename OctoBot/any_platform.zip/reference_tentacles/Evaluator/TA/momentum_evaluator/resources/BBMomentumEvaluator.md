Uses the [Bollinger bands](https://www.investopedia.com/terms/b/bollingerbands.asp)  to evaluate a value from -1 to 1 according to the current price 
distance from to the [Bollinger bands](https://www.investopedia.com/terms/b/bollingerbands.asp) values.
