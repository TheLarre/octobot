Uses [Klinger Oscillator](https://www.investopedia.com/terms/k/klingeroscillator.asp) to find reversals.

Evaluates -1 to 1 using [Klinger](https://www.investopedia.com/terms/k/klingeroscillator.asp) reversal estimation