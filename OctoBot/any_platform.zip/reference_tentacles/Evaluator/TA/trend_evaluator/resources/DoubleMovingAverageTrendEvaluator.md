Uses two [moving averages](https://www.investopedia.com/terms/m/movingaverage.asp) (a slow and a fast one) to find reversals.

Evaluates from -1 to 1 relatively to the computed reversal probability and the current price distance from 
[moving averages](https://www.investopedia.com/terms/m/movingaverage.asp).