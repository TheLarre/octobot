Uses [exponential moving averages](https://www.investopedia.com/terms/e/ema.asp) to find price divergences.

Evaluates from -1 to 1 relatively to the computed divergence strength.