First initialises using the recent history of the subreddits in RedditForumEvaluator.json then
watches for new posts to update its evaluation. 

Never triggers strategies re-evaluations, acts as a background evaluator
