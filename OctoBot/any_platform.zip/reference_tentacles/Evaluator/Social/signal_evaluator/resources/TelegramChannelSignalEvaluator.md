Evaluator that catch Telegram channel signals.

Triggers on a Telegram signal from any channel your personal account joined.

Signal parsing is configurable according to the name of the channel.

See [OctoBot docs about Telegram API service](https://www.octobot.info/interfaces/telegram-interface/telegram-api) for more information.
